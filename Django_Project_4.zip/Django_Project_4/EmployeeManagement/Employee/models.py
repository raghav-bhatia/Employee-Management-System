from django.db import models

# Create your models here.

class Employee(models.Model):
    emp_Fname=models.CharField(max_length=50)
    emp_Lname=models.CharField(max_length=50)
    emp_Email=models.EmailField(max_length=254)
    emp_Mobile=models.IntegerField()
