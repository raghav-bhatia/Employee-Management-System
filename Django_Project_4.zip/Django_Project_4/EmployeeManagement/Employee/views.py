from django.shortcuts import render,redirect
from .forms import EmployeeDetails
from .models import Employee
from django.core.paginator import Paginator

# Create your views here.

def addEmployee(request):
    if request.method=='POST':
        fm=EmployeeDetails(request.POST)
        if fm.is_valid:
            fm.save()
            fm=EmployeeDetails()
    else:
        fm=EmployeeDetails()
    return render(request,'addEmp.html',{'form':fm})

def ShowEmp(request):
    empD=Employee.objects.all()

    pagin=Paginator(empD,2)
    pageNum=request.GET.get('page')
    PgFinal=pagin.get_page(pageNum)
    totalPage=PgFinal.paginator.num_pages
    context={
        'empD':PgFinal,
        'totalPagelist':[n+1 for n in range(totalPage) ]
    }

    if request.method=="GET":
        s_emp=request.GET.get('searchname')
        if s_emp!=None:
            empD=Employee.objects.filter(emp_Fname__icontains=s_emp)
            searchedEmp = {'empD': empD}
            return render(request,'ShowEmp.html',searchedEmp)
    
    return render(request,'showEmp.html',context)
    #return render(request,'showEmp.html',{'empD':empD})

def deleteEmp(request,id):
    if request.method=='POST':
        del_Emp=Employee.objects.get(pk=id)
        del_Emp.delete()
    return redirect('/show')

def updateEmp(request,id):
    if request.method=='POST':
        upd_Emp=Employee.objects.get(pk=id)
        fm=EmployeeDetails(request.POST,instance=upd_Emp)
        if fm.is_valid:
            fm.save()
            return redirect('/show') 
    else:
     upd_Emp=Employee.objects.get(pk=id)
     fm=EmployeeDetails(instance=upd_Emp)
     

    return render(request,'updateEmp.html',{'form':fm})
