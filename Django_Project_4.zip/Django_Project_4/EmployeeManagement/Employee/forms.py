from django import forms
from .models import Employee

class EmployeeDetails(forms.ModelForm):
    class Meta:
        model=Employee
        fields=['emp_Fname','emp_Lname','emp_Email','emp_Mobile']
        widgets={
            'emp_Fname':forms.TextInput(attrs={'class':'form-control'}),
            'emp_Lname':forms.TextInput(attrs={'class':'form-control'}),
            'emp_Email':forms.EmailInput(attrs={'class':'form-control'}),
            'emp_Mobile':forms.NumberInput(attrs={'class':'form-control'}),
        }